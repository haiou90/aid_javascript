var faderData = [
    {
        "img_url":"banner01.jpg",
        "img_info":"爬虫微课5小时 python学习路线!"
    },
    {
        "img_url":"banner02.jpg",
        "img_info":"干货|如何优雅的在手机上进行Python编程"
    },
    {
        "img_url":"banner03.jpg",
        "img_info":"python-win10下使用定时任务执行程序"
    }
]
